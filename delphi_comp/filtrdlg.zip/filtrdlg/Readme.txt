TFilterDialog v1.0

Author : Roz Herv�
E-Mail : hroz@caramail.com

Description:
A VCL that allows you to perform table filter operation, by selecting column name, operator and assigning values in a filter dialog box.

Extra :
A sample project is provided but to run it, you must before add the unit into the delphi user packet.

Known Issues:

Revision History:
 1.00:  + Initial release
