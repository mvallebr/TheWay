TFloatSpinEdit 1.0 component for Delphi

FREEWARE

(c)1999 Deso
dsodol@hotmail.com

INSTALLATION:

1. Unrar
2. In Delphi: Component->Install component...->Browse...
