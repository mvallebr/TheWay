SciBit MySQL Components Readme & Installation
---------------------------------------------

Description:
------------
This is the SciBit's Delphi 5 or 6 or Kylix 1 single source components for MySQL servers >3.21.x

These components was tested with all MySQL servers from 3.21.x to 3.23.x.

For support please contact SciBit at: 
web: http://www.scibit.com 
email: support@scibit.com

Components Installation:
------------------------
Only Delphi 5/6 and Kylix 1 is supported.

	Shareware Installation:
	-----------------------
0. If installed, uninstall any previous versions of this component set in Delphi/Kylix.
1. Make sure the .\libmysql.dll (Windows) or ./libmysqlclient.so (Linux) file that came with this installation is always available somewhere on your PATH or to the project you are compiling, win\system32 (Windows) or /bin (Linux) directory or the project's directory would be good choices. 
2. In Kylix or Delphi click the Component-Install Packages menu, then click Add
3. Depending on your Delphi or Kylix version goto the corresponding directory:
	..\D5	Delphi 5
	..\D6	Delphi 6
	..\K1	Kylix 1
4. Pick the SBMySQL?0.bpl for Delphi or the bplsbmysqlk10.so file for Kylix then click Open
5. Click Tools-Environment Options menu, then click Library, and add the same directory (/K1,/D5,/D6) to the Library Path.

	Full Installation:
	------------------
0. If installed, uninstall any previous versions of this component set in Delphi/Kylix.
1. Make sure the .\libmysql.dll (Windows) or ./libmysqlclient.so (Linux) file that came with this installation is always available somewhere on your PATH or to the project you are compiling, win\system32 (Windows) or /bin (Linux) directory or the project's directory would be good choices. 
2. Click Open, then open the file: 
	./Source/SBMySQL50.dpk	Delphi 5
	./Source/SBMySQL60.dpk	Delphi 6
	./Source/SBMySQLK10.dpk Kylix 1
4. Click Compile and then Install.
5. Click Tools-Environment Options menu, then the Library, and add the ./Source and optionally the ./K1 or /D5 or /D6 directories to the Library Path.

Help File:
----------
To install the help file in Delphi 5 or 6's OpenHelp:
1. Click Help then Customize
2. Click Edit then Add Files
3. Add the MySQLComponents.hlp file on the first three tabs.
4. Click File-Save
5. Close OpenHelp

Alternative Help:
HTML Help is also available and can be found in the installation directory with index file named: ./Help/HTML/hs100.htm

Examples:
---------
For examples see your corresponding directory:
./D5/Demo
./D6/Demo
./K1/Demo

Copyright 2000,2001, SciBit