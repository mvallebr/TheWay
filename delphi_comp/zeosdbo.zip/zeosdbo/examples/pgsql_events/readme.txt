PostgreSQL Notify Components Test
-----------------------------------------------------

This is a simple test to demostrate Zeos PostgreSQL notifying capabilities.
Fill the database properties according to your server (host, user,
password, database) and run the demo.
Then press "Create Table" to create the table structure, "Connect" to connect
to the database and activate the grid, "Activate" to activate the Notify
component, "Set Events" to set the events list (that Memo which appears
left on screen) then finally press "Notify!" to fire an event.
Also any updates to rows will trigger the same event (because of the rule
in the SQL script from bsCreate).

Howe
20/01/2001
